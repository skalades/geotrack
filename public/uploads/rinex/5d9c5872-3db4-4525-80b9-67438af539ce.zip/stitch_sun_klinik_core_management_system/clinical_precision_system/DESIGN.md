---
name: Clinical Precision System
colors:
  surface: '#f6fbf2'
  surface-dim: '#d7dbd3'
  surface-bright: '#f6fbf2'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f5ed'
  surface-container: '#ebefe7'
  surface-container-high: '#e5eae1'
  surface-container-highest: '#dfe4dc'
  on-surface: '#181d18'
  on-surface-variant: '#3f493f'
  inverse-surface: '#2d322c'
  inverse-on-surface: '#eef2ea'
  outline: '#6f7a6e'
  outline-variant: '#bfc9bc'
  surface-tint: '#116d34'
  primary: '#005927'
  on-primary: '#ffffff'
  primary-container: '#1b7339'
  on-primary-container: '#9ff5ad'
  inverse-primary: '#84d993'
  secondary: '#555f71'
  on-secondary: '#ffffff'
  secondary-container: '#d6e0f6'
  on-secondary-container: '#596376'
  tertiary: '#852f42'
  on-tertiary: '#ffffff'
  tertiary-container: '#a34659'
  on-tertiary-container: '#ffd9dd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#a0f6ad'
  primary-fixed-dim: '#84d993'
  on-primary-fixed: '#00210a'
  on-primary-fixed-variant: '#005323'
  secondary-fixed: '#d9e3f9'
  secondary-fixed-dim: '#bdc7dc'
  on-secondary-fixed: '#121c2c'
  on-secondary-fixed-variant: '#3d4759'
  tertiary-fixed: '#ffd9dd'
  tertiary-fixed-dim: '#ffb2bd'
  on-tertiary-fixed: '#400014'
  on-tertiary-fixed-variant: '#7d293c'
  background: '#f6fbf2'
  on-background: '#181d18'
  surface-variant: '#dfe4dc'
  clinical-green-light: '#E8F5E9'
  alert-warning: '#F59E0B'
  alert-critical: '#DC2626'
  alert-info: '#2563EB'
  background-subtle: '#F8FAFC'
  border-default: '#E2E8F0'
typography:
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-desktop: 24px
  margin-mobile: 16px
  table-condensed: 8px
  container-max: 1440px
---

## Brand & Style

The design system is engineered for the high-stakes environment of medical back-office management. The brand personality is **Clinical, Systematic, and Vigilant**, prioritizing utility and cognitive ease over decorative flair. It is designed for medical professionals—doctors, nurses, and administrators—who require speed, accuracy, and reliability in their daily workflows.

The visual style is **Corporate / Modern**, leaning heavily into functional minimalism. It uses a structured information architecture to handle complex EHR data and regulatory compliance standards (SATUSEHAT). The interface conveys trust through technical precision: clear borders, high-contrast text, and a focused clinical palette that emphasizes "status" and "action" over "aesthetic."

## Colors

This design system utilizes a palette rooted in clinical hygiene and administrative clarity. The **Primary Clinical Green** (derived from the Sun Klinik logo) is reserved for primary actions, success states, and brand-identifiable elements like headers or active navigation states.

To manage the high density of information in EHR and inventory modules, a robust **Neutral Gray** scale is used to define hierarchy and surface depth. 

Functional colors are critical:
- **Alert Critical (Red):** Used exclusively for stock expiry, medical alerts, and destructive actions.
- **Alert Warning (Amber):** Used for low stock levels and pending validations.
- **Alert Info (Blue):** Used for system logs and audit trail updates.
- **Clinical Green Light:** Used as a subtle background tint for successful validation screens or "Check-in" status badges to reduce eye strain.

## Typography

Typography focuses on legibility and data density. 

**Hanken Grotesk** is used for headlines to provide a modern, sharp professional feel. **Inter** is the workhorse for all body text, chosen for its exceptional legibility in dense UI environments like medical records and e-prescriptions. **JetBrains Mono** is introduced specifically for technical data—ICD-10 codes, QRIS transaction IDs, and Audit Trail timestamps—to ensure each character is distinct and easily scannable.

For mobile-specific screens used in Nurse Triage, `headline-lg-mobile` should scale down to `24px` to maintain screen real estate while preserving hierarchy.

## Layout & Spacing

The system employs a **12-column fluid grid** for desktop dashboards, transitioning to a simplified stacked layout for tablet and mobile. 

A strict **4px baseline grid** governs all spacing. In information-heavy modules such as "Inventory Control" or "SOAP Records," the system shifts to a **"Condensed" mode**, reducing vertical padding to `8px` within table rows and list items. This maximizes the amount of visible data without sacrificing touch targets on mobile devices.

Breakpoints:
- **Desktop:** 1280px+ (12 columns, 24px margins)
- **Tablet:** 768px - 1279px (8 columns, 20px margins)
- **Mobile:** <767px (4 columns, 16px margins)

## Elevation & Depth

This design system uses **Tonal Layers** and **Low-Contrast Outlines** rather than heavy shadows to maintain a clean, clinical aesthetic. 

- **Level 0 (Base):** `#F8FAFC` (Background-subtle) for the main canvas.
- **Level 1 (Surface):** White cards with a `1px` solid border in `#E2E8F0`. No shadow. Used for standard data sections.
- **Level 2 (Active/Floating):** Subtle ambient shadow (0px 4px 12px rgba(0,0,0,0.05)) and `#FFFFFF` surface. Reserved for active dropdowns and tooltips.
- **Level 3 (Modal):** Centered overlays with a 20% opacity black backdrop blur. Used for critical interruptions like "Session Timeout" or "Prescription Validation."

Dividers are used aggressively but subtly (`1px` hairlines) to separate the Subjective, Objective, Assessment, and Plan (SOAP) sections within patient records.

## Shapes

The shape language is **Soft (0.25rem/4px)**. This minimal rounding provides a modern touch without feeling overly "consumer-grade" or playful. 

- **Standard Elements:** (Buttons, Input fields, Checkboxes) use `rounded` (4px).
- **Cards & Large Containers:** Use `rounded-lg` (8px) to define structural boundaries.
- **Status Badges:** Use `rounded-xl` (12px) to differentiate them from interactive buttons.
- **Selection Indicators:** (Active menu items) use a `2px` vertical bar on the left side of the element in the Primary Clinical Green to indicate focus.

## Components

### Buttons
- **Primary:** Solid Clinical Green with white text. Used for "Save Record," "Validate," and "Check-in."
- **Secondary:** Outline Primary Green with transparent background. Used for "Add Row" or "Print Receipt."
- **Ghost:** Gray text, no border. Used for "Cancel" or "Clear Filters."

### Data Tables
Tables are the heart of SIMKLI. They must feature:
- **Sticky Headers:** Always visible when scrolling.
- **Zebra Striping:** Alternating `#F8FAFC` rows for horizontal tracking.
- **Status Chips:** High-contrast capsules (e.g., Red for "Expired," Green for "Available").

### Input Fields
- **Default:** White background, `1px` gray border.
- **Focus State:** `2px` Primary Green border with no outer glow.
- **Error State:** `1px` Critical Red border with a small supporting text label below the field.

### Chips & Status Indicators
- Use `label-caps` typography for status chips.
- **Stock Alert:** Amber background with dark amber text.
- **Expiry:** Red background with white text.

### Cards
Cards are the primary container for "Executive Analytics." They should be flat, using a `1px` border to define boundaries. Avoid inner padding exceeding `24px` to keep data density high.